
export interface Task {
  id: string;
  text: string;
  completed: boolean;
  toolSuggestion?: string;
}

export interface DayPlan {
  day: number;
  revenueTarget: number;
  focus: string;
  description: string;
  tasks: Task[];
}

export interface UserProgress {
  currentDay: number;
  actualEarnings: Record<number, number>; // day number -> amount
  isPlanGenerated: boolean;
  niche: string;
  createdAt: string;
  isProMember?: boolean;
}

export interface ResourceLink {
  name: string;
  url: string;
  category: 'AI' | 'Marketplace' | 'Social' | 'Design' | 'Hosting';
  description: string;
  badge?: string;
  cta?: string; // Call to Action text
}

// REPLACE THESE URLS WITH YOUR ACTUAL AFFILIATE LINKS TO EARN COMMISSIONS
export const FREE_TOOLS: ResourceLink[] = [
  { 
    name: 'Gemini Advanced', 
    url: 'https://one.google.com/explore-plan/gemini-advanced?utm_source=YOUR_ID', 
    category: 'AI', 
    description: 'The brain behind this app. Upgrade for faster reasoning.', 
    badge: 'Power Engine',
    cta: 'Start Free Trial'
  },
  { 
    name: 'Shopify', 
    url: 'https://shopify.pxf.io/YOUR_AFFILIATE_ID', 
    category: 'Marketplace', 
    description: 'The #1 platform to sell products. $1/month trial available.', 
    badge: 'Top Rated',
    cta: 'Claim $1/mo Offer'
  },
  { 
    name: 'Canva Pro', 
    url: 'https://partner.canva.com/YOUR_AFFILIATE_ID', 
    category: 'Design', 
    description: 'Design logos, social posts, and ads in seconds.', 
    badge: 'Essential',
    cta: 'Try Pro Free'
  },
  { 
    name: 'Bluehost', 
    url: 'https://www.bluehost.com/track/YOUR_AFFILIATE_ID', 
    category: 'Hosting', 
    description: 'Professional website hosting. Free domain included.', 
    badge: '70% OFF',
    cta: 'Get Hosting Deal'
  },
  { 
    name: 'System.io', 
    url: 'https://system.io/?sa=YOUR_AFFILIATE_ID', 
    category: 'Marketplace', 
    description: 'All-in-one funnel builder. Free forever plan available.', 
    badge: 'Free Funnels',
    cta: 'Create Free Account'
  },
  { 
    name: 'CapCut Desktop', 
    url: 'https://www.capcut.com', 
    category: 'Design', 
    description: 'Viral video editing for TikTok/Reels.', 
    cta: 'Download'
  },
  { 
    name: 'Fiverr', 
    url: 'https://go.fiverr.com/visit/?bta=YOUR_ID', 
    category: 'Marketplace', 
    description: 'Outsource tasks or sell your own services.', 
    cta: 'Find Services'
  },
];
