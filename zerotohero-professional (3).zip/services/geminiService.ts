
import { GoogleGenAI, Type } from "@google/genai";
import { DayPlan } from "../types";

const createClient = () => {
  // Prioritize key from LocalStorage (User setting), fallback to env var (Developer setting)
  const storedKey = localStorage.getItem('zh_api_key');
  let envKey = '';
  
  // Safe check for process.env in browser environments
  try {
    // @ts-ignore
    if (typeof process !== 'undefined' && process.env) {
      // @ts-ignore
      envKey = process.env.API_KEY;
    }
  } catch (e) {
    // Ignore reference errors
  }

  const apiKey = storedKey || envKey;

  if (!apiKey) {
    throw new Error("API Key missing. Please add your Gemini API Key in Settings.");
  }
  return new GoogleGenAI({ apiKey });
};

export const generateHustlePlan = async (niche: string = "General"): Promise<DayPlan[]> => {
  const ai = createClient();

  const systemInstruction = `
    You are a world-class digital business strategist and growth hacker.
    Your client has $0 capital, no audience, and needs to generate revenue in 14 days.
    
    Create a highly professional, aggressive, step-by-step execution roadmap.
    
    The Plan Structure:
    - Phase 1 (Day 1-3): Foundation & Quick Validation (Target: $0-$100)
    - Phase 2 (Day 4-7): Content Velocity & Outreach (Target: $100-$500)
    - Phase 3 (Day 8-14): Scaling & Automation (Target: $500-$2000)

    Constraints:
    - Niche: "${niche}".
    - Tools: FREE tools only.
    - Tone: Professional, directive, no fluff.
    - Tasks: Must be concrete actions (e.g., "Draft 5 cold DMs," "Post 3 TikToks," "Create Gumroad landing page").
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Generate a 14-day revenue roadmap for the "${niche}" niche. Return strictly JSON.`,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              day: { type: Type.INTEGER },
              revenueTarget: { type: Type.INTEGER },
              focus: { type: Type.STRING },
              description: { type: Type.STRING },
              tasks: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    text: { type: Type.STRING },
                    toolSuggestion: { type: Type.STRING, description: "Specific free tool name" }
                  },
                  required: ["text"]
                }
              }
            },
            required: ["day", "revenueTarget", "focus", "description", "tasks"]
          }
        }
      }
    });

    if (response.text) {
      let text = response.text;
      // Clean up markdown if present (e.g. ```json ... ```)
      if (text.startsWith('```')) {
        text = text.replace(/^```(json)?\n/, '').replace(/```$/, '');
      }
      const rawData = JSON.parse(text);
      return rawData.map((day: any) => ({
        ...day,
        tasks: day.tasks.map((t: any, idx: number) => ({
          id: `d${day.day}-t${idx}`,
          text: t.text,
          toolSuggestion: t.toolSuggestion,
          completed: false
        }))
      }));
    }
    throw new Error("No plan generated");
  } catch (error) {
    console.error("Plan generation failed:", error);
    // Rethrow if it's an API key issue so the UI can handle it
    if (error instanceof Error && (error.message.includes("API Key") || error.message.includes("403"))) {
        throw new Error("Invalid API Key. Please check your settings.");
    }
    return fallbackPlan;
  }
};

export const askMentor = async (question: string, context: string, day: number): Promise<string> => {
  try {
    const ai = createClient();
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Context: Day ${day} of a 14-day zero-budget business launch. Current focus: ${context}.
      User Question: "${question}"
      
      Provide a strategic, high-level mentor response. Be encouraging but realistic. Keep it under 50 words.`,
    });
    return response.text || "Stay focused on the current task. Momentum is key.";
  } catch (e) {
    return "Please configure your API Key in Settings to chat with the Mentor.";
  }
};

const fallbackPlan: DayPlan[] = [
  {
    day: 1,
    revenueTarget: 0,
    focus: "Market Analysis & Setup",
    description: "Identify a gap in the market. We are looking for high demand, low competition, or a unique angle on a popular topic.",
    tasks: [
      { id: 'd1-1', text: 'Use Google Trends & TikTok Search to find 3 trending problems people are complaining about.', completed: false, toolSuggestion: 'Google Trends' },
      { id: 'd1-2', text: 'Define your "Irresistible Offer" - what value can you provide for free to get attention?', completed: false, toolSuggestion: 'Gemini' },
      { id: 'd1-3', text: 'Set up professional social accounts (clean bio, link-in-bio placeholder).', completed: false },
    ]
  },
  {
    day: 2,
    revenueTarget: 50,
    focus: "The First Offer",
    description: "Launch a 'Minimum Viable Service' or product. Speed is more important than perfection.",
    tasks: [
      { id: 'd2-1', text: 'Create a simple service listing (e.g., Thumbnail design, Copywriting) on Twitter/X or Fiverr.', completed: false, toolSuggestion: 'Canva' },
      { id: 'd2-2', text: 'Find 10 potential clients on social media and send a personalized DM offering value first.', completed: false },
      { id: 'd2-3', text: 'Join 3 relevant Facebook groups or Discord servers to network (do not spam).', completed: false },
    ]
  }
];
