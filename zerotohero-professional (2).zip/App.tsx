
import React, { useState, useEffect } from 'react';
import { Zap, Layout, TrendingUp, BookOpen, Menu, X, RefreshCcw, ExternalLink, BarChart3, Rocket, Target, Settings, Key, Crown, Lock, Check, ArrowRight, Link as LinkIcon, Share2, Copy } from 'lucide-react';
import { generateHustlePlan } from './services/geminiService';
import { DayPlan, UserProgress, FREE_TOOLS } from './types';
import DayView from './components/DayView';
import ProgressChart from './components/ProgressChart';

const INITIAL_PROGRESS: UserProgress = {
  currentDay: 1,
  actualEarnings: {},
  isPlanGenerated: false,
  niche: "",
  createdAt: new Date().toISOString(),
  isProMember: false,
};

function App() {
  // State
  const [progress, setProgress] = useState<UserProgress>(() => {
    const saved = localStorage.getItem('zh-progress');
    return saved ? JSON.parse(saved) : INITIAL_PROGRESS;
  });

  const [plan, setPlan] = useState<DayPlan[]>(() => {
    const saved = localStorage.getItem('zh-plan');
    return saved ? JSON.parse(saved) : [];
  });

  const [isLoading, setIsLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0); 
  const [nicheInput, setNicheInput] = useState('');
  const [activeTab, setActiveTab] = useState<'plan' | 'stats' | 'tools'>('plan');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  // Settings State
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isUpgradeOpen, setIsUpgradeOpen] = useState(false);
  const [apiKey, setApiKey] = useState(() => localStorage.getItem('zh_api_key') || '');
  
  // Affiliate IDs State
  const [affiliateIds, setAffiliateIds] = useState<{ [key: string]: string }>(() => {
    const saved = localStorage.getItem('zh_affiliate_ids');
    return saved ? JSON.parse(saved) : {};
  });

  // Persistence
  useEffect(() => {
    localStorage.setItem('zh-progress', JSON.stringify(progress));
  }, [progress]);

  useEffect(() => {
    localStorage.setItem('zh-plan', JSON.stringify(plan));
  }, [plan]);

  const handleSaveSettings = () => {
    localStorage.setItem('zh_api_key', apiKey);
    localStorage.setItem('zh_affiliate_ids', JSON.stringify(affiliateIds));
    setIsSettingsOpen(false);
    alert("Configuration saved successfully!");
  };

  // Handlers
  const handleGeneratePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nicheInput.trim()) return;
    
    setIsLoading(true);
    
    const steps = ["Analyzing Market...", "Structuring Revenue...", "Finalizing Roadmap..."];
    let stepIdx = 0;
    setLoadingStep(0);
    
    // Faster animation speed (500ms instead of 1500ms)
    const interval = setInterval(() => {
      if (stepIdx < steps.length) {
        setLoadingStep(prev => prev + 1);
        stepIdx++;
      }
    }, 500);

    try {
      const generatedPlan = await generateHustlePlan(nicheInput);
      clearInterval(interval);
      setPlan(generatedPlan);
      setProgress(prev => ({ 
        ...prev, 
        isPlanGenerated: true, 
        niche: nicheInput,
        createdAt: new Date().toISOString()
      }));
    } catch (err) {
      clearInterval(interval);
      if (err instanceof Error && err.message.includes("API Key")) {
         setIsSettingsOpen(true);
      } else {
         alert("Could not generate plan. Please check your API key or internet connection.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleTask = (day: number, taskId: string) => {
    setPlan(prevPlan => prevPlan.map(d => {
      if (d.day !== day) return d;
      return {
        ...d,
        tasks: d.tasks.map(t => t.id === taskId ? { ...t, completed: !t.completed } : t)
      };
    }));
  };

  const handleUpdateEarnings = (amount: number) => {
    setProgress(prev => ({
      ...prev,
      actualEarnings: { ...prev.actualEarnings, [prev.currentDay]: amount }
    }));
  };

  const handleReset = () => {
    if (window.confirm("CAUTION: This will permanently delete your current business roadmap and financial data. Continue?")) {
      localStorage.removeItem('zh-progress');
      localStorage.removeItem('zh-plan');
      setProgress(INITIAL_PROGRESS);
      setPlan([]);
      setNicheInput('');
      setActiveTab('plan');
    }
  };

  const handleUpgrade = () => {
    // Simulate upgrade process
    const confirmPurchase = window.confirm("Secure Checkout Simulation:\n\nProduct: ZeroToHero Pro\nPrice: $29.00\n\nClick OK to confirm purchase.");
    if (confirmPurchase) {
        setProgress(prev => ({ ...prev, isProMember: true }));
        setIsUpgradeOpen(false);
        alert("Welcome to Pro! All limits have been removed.");
    }
  };
  
  const handleShare = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url).then(() => {
        alert("App link copied to clipboard! Send this to your users.");
    });
  };

  // Helper to inject affiliate IDs into URLs
  const getToolUrl = (tool: typeof FREE_TOOLS[0]) => {
    let url = tool.url;
    const ids = affiliateIds;
    
    if (tool.name.includes('Shopify') && ids.shopify) return url.replace('YOUR_AFFILIATE_ID', ids.shopify);
    if (tool.name.includes('Canva') && ids.canva) return url.replace('YOUR_AFFILIATE_ID', ids.canva);
    if (tool.name.includes('Bluehost') && ids.bluehost) return url.replace('YOUR_AFFILIATE_ID', ids.bluehost);
    if (tool.name.includes('System.io') && ids.systemio) return url.replace('YOUR_AFFILIATE_ID', ids.systemio);
    if (tool.name.includes('Fiverr') && ids.fiverr) return url.replace('YOUR_ID', ids.fiverr);
    
    return url;
  };

  const totalEarnings = Object.values(progress.actualEarnings).reduce((acc: number, val: number) => acc + val, 0);

  const currentDayPlan = plan.find(p => p.day === progress.currentDay) || {
    day: progress.currentDay,
    revenueTarget: 0,
    focus: "Plan Loading",
    description: "",
    tasks: []
  };

  // --- RENDER ---

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans flex flex-col md:flex-row overflow-hidden">
      
      {/* Sidebar */}
      <aside className="hidden md:flex w-72 bg-slate-925 border-r border-slate-800 flex-col relative z-20">
        <div className="p-6 flex items-center gap-3 border-b border-slate-800/50">
          <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center text-slate-900 font-bold">Z</div>
          <div>
            <span className="text-lg font-bold text-white tracking-tight block leading-none">ZeroToHero</span>
            {progress.isProMember && <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">Pro Member</span>}
          </div>
        </div>

        <div className="p-4 space-y-1 flex-1">
          <button 
            onClick={() => setActiveTab('plan')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${activeTab === 'plan' ? 'bg-emerald-500/10 text-emerald-400' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
          >
            <Layout size={20} /> Action Plan
          </button>
          <button 
            onClick={() => setActiveTab('stats')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${activeTab === 'stats' ? 'bg-emerald-500/10 text-emerald-400' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
          >
            <TrendingUp size={20} /> Financials
          </button>
          <button 
            onClick={() => setActiveTab('tools')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${activeTab === 'tools' ? 'bg-emerald-500/10 text-emerald-400' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
          >
            <BookOpen size={20} /> Resources
          </button>
        </div>

        <div className="p-6 space-y-4">
            {!progress.isProMember && (
              <button 
                onClick={() => setIsUpgradeOpen(true)}
                className="w-full group relative overflow-hidden rounded-xl bg-gradient-to-br from-violet-600 to-indigo-600 p-4 text-left shadow-lg shadow-violet-900/20 transition-transform hover:scale-[1.02]"
              >
                <div className="absolute top-0 right-0 -mt-2 -mr-2 h-16 w-16 rounded-full bg-white/10 blur-xl"></div>
                <div className="relative flex items-center gap-3">
                  <div className="rounded-lg bg-white/20 p-2 text-white">
                    <Crown size={20} />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-violet-100 uppercase tracking-wide">Unlock Pro</p>
                    <p className="text-sm font-bold text-white">Remove Limits</p>
                  </div>
                </div>
              </button>
            )}

            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
                <p className="text-xs text-slate-500 font-medium mb-1 uppercase tracking-wide">Total Revenue</p>
                <p className="text-2xl font-mono font-bold text-white">${totalEarnings.toLocaleString()}</p>
            </div>
            <div className="flex gap-2">
              <button 
                onClick={() => setIsSettingsOpen(true)}
                className="flex-1 flex items-center justify-center gap-2 px-2 py-2 rounded-lg text-xs font-medium text-slate-400 hover:text-white hover:bg-slate-800 transition-colors border border-slate-800"
              >
                <Settings size={14} /> Settings
              </button>
              <button 
                onClick={handleReset} 
                className="flex-1 flex items-center justify-center gap-2 text-xs font-medium text-slate-600 hover:text-red-400 hover:bg-slate-800/50 border border-transparent hover:border-red-900/30 rounded-lg transition-colors"
              >
                <RefreshCcw size={12} /> Reset
              </button>
            </div>
        </div>
      </aside>

      {/* Mobile Header */}
      <header className="md:hidden bg-slate-900 border-b border-slate-800 p-4 flex justify-between items-center sticky top-0 z-50">
         <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center text-slate-900 font-bold">Z</div>
            <span className="font-bold text-white">ZeroToHero</span>
         </div>
         <div className="flex items-center gap-4">
            {!progress.isProMember && (
               <button onClick={() => setIsUpgradeOpen(true)} className="text-xs font-bold bg-violet-600 text-white px-3 py-1.5 rounded-full">
                  Upgrade
               </button>
            )}
            <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="text-slate-400">
                {isMobileMenuOpen ? <X /> : <Menu />}
            </button>
         </div>
      </header>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
          <div className="md:hidden fixed inset-0 bg-slate-950 z-40 pt-20 px-6 space-y-4 animate-fade-in">
            <button onClick={() => {setActiveTab('plan'); setIsMobileMenuOpen(false)}} className="text-xl font-bold text-white block py-2 border-b border-slate-800 w-full text-left">Action Plan</button>
            <button onClick={() => {setActiveTab('stats'); setIsMobileMenuOpen(false)}} className="text-xl font-bold text-white block py-2 border-b border-slate-800 w-full text-left">Financials</button>
            <button onClick={() => {setActiveTab('tools'); setIsMobileMenuOpen(false)}} className="text-xl font-bold text-white block py-2 border-b border-slate-800 w-full text-left">Resources</button>
            <button onClick={() => {setIsSettingsOpen(true); setIsMobileMenuOpen(false)}} className="text-xl font-bold text-slate-400 block py-2 border-b border-slate-800 w-full text-left flex items-center gap-2"><Settings size={20} /> Settings</button>
            <button onClick={handleReset} className="text-red-500 block py-4 text-sm font-bold">Reset Everything</button>
          </div>
      )}

      {/* Settings Modal */}
      {isSettingsOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-[60] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Settings size={20} className="text-emerald-500" /> Configuration
                </h2>
                <p className="text-slate-400 text-sm mt-1">Configure your AI engine & income.</p>
              </div>
              <button onClick={() => setIsSettingsOpen(false)} className="text-slate-500 hover:text-white"><X size={20} /></button>
            </div>

            <div className="space-y-6">
              {/* API Key Section */}
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Gemini API Key</label>
                <div className="relative">
                  <input 
                    type="password" 
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    placeholder="AIzaSy..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-3 pl-10 pr-4 text-white focus:outline-none focus:border-emerald-500 transition-all font-mono text-sm"
                  />
                  <Key size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600" />
                </div>
                <p className="text-[10px] text-slate-500 mt-2">
                  Required for the app to function. 
                  <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noreferrer" className="text-emerald-400 hover:underline ml-1">Get a free key here.</a>
                </p>
              </div>

              {/* Affiliate Config Section */}
              <div className="pt-6 border-t border-slate-800/50">
                <div className="flex items-center gap-2 mb-4">
                    <LinkIcon size={16} className="text-emerald-500" />
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Affiliate Monetization</label>
                </div>
                <p className="text-[10px] text-slate-500 mb-3">
                    Enter your personal affiliate IDs below. The app will replace default links in the "Resources" tab with your links, so you earn commissions.
                </p>
                
                <div className="space-y-3">
                    <div className="relative">
                        <input 
                            type="text" 
                            value={affiliateIds.shopify || ''}
                            onChange={(e) => setAffiliateIds({...affiliateIds, shopify: e.target.value})}
                            placeholder="Shopify ID"
                            className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2 px-3 text-sm text-white focus:border-emerald-500 focus:outline-none"
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[9px] font-bold text-slate-600">SHOPIFY</span>
                    </div>
                    <div className="relative">
                        <input 
                            type="text" 
                            value={affiliateIds.fiverr || ''}
                            onChange={(e) => setAffiliateIds({...affiliateIds, fiverr: e.target.value})}
                            placeholder="Fiverr ID"
                            className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2 px-3 text-sm text-white focus:border-emerald-500 focus:outline-none"
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[9px] font-bold text-slate-600">FIVERR</span>
                    </div>
                    <div className="relative">
                        <input 
                            type="text" 
                            value={affiliateIds.canva || ''}
                            onChange={(e) => setAffiliateIds({...affiliateIds, canva: e.target.value})}
                            placeholder="Canva ID"
                            className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2 px-3 text-sm text-white focus:border-emerald-500 focus:outline-none"
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[9px] font-bold text-slate-600">CANVA</span>
                    </div>
                     <div className="relative">
                        <input 
                            type="text" 
                            value={affiliateIds.bluehost || ''}
                            onChange={(e) => setAffiliateIds({...affiliateIds, bluehost: e.target.value})}
                            placeholder="Bluehost ID"
                            className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2 px-3 text-sm text-white focus:border-emerald-500 focus:outline-none"
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[9px] font-bold text-slate-600">BLUEHOST</span>
                    </div>
                     <div className="relative">
                        <input 
                            type="text" 
                            value={affiliateIds.systemio || ''}
                            onChange={(e) => setAffiliateIds({...affiliateIds, systemio: e.target.value})}
                            placeholder="System.io ID"
                            className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2 px-3 text-sm text-white focus:border-emerald-500 focus:outline-none"
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[9px] font-bold text-slate-600">SYSTEM.IO</span>
                    </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800/50">
                  <button onClick={handleShare} className="w-full flex items-center justify-center gap-2 text-sm text-slate-400 hover:text-white py-2 border border-slate-800 rounded-lg hover:bg-slate-800 transition-colors">
                      <Share2 size={14} /> Share App Link
                  </button>
              </div>

              <button 
                onClick={handleSaveSettings}
                className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold py-3 rounded-xl transition-colors shadow-lg shadow-emerald-500/20"
              >
                Save Configuration
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Upgrade / Paywall Modal */}
      {isUpgradeOpen && (
        <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-md z-[70] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-8 max-w-md w-full shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-violet-500 via-fuchsia-500 to-violet-500"></div>
            <button onClick={() => setIsUpgradeOpen(false)} className="absolute top-4 right-4 text-slate-500 hover:text-white"><X size={24} /></button>
            
            <div className="text-center mb-8 mt-2">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-violet-500/10 text-violet-400 mb-4 border border-violet-500/20">
                <Crown size={32} />
              </div>
              <h2 className="text-2xl font-black text-white">Unlock Full Potential</h2>
              <p className="text-slate-400 mt-2">Get the unfair advantage to reach $2,000 faster.</p>
            </div>

            <div className="space-y-4 mb-8">
              <div className="flex items-center gap-3">
                <div className="p-1 rounded-full bg-emerald-500/10 text-emerald-400"><Check size={14} /></div>
                <span className="text-slate-200 text-sm">Unlimited AI Strategy Generations</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="p-1 rounded-full bg-emerald-500/10 text-emerald-400"><Check size={14} /></div>
                <span className="text-slate-200 text-sm">Advanced Niche Analysis</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="p-1 rounded-full bg-emerald-500/10 text-emerald-400"><Check size={14} /></div>
                <span className="text-slate-200 text-sm">Priority Mentor Support</span>
              </div>
            </div>

            <button 
              onClick={handleUpgrade}
              className="w-full bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-bold py-4 rounded-xl transition-all shadow-xl shadow-violet-900/20 flex items-center justify-center gap-2 group"
            >
              Unlock Pro - $29 <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </button>
            <p className="text-center text-[10px] text-slate-500 mt-4">One-time payment. Secure checkout.</p>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto relative scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-transparent">
        {/* Onboarding View */}
        {!progress.isPlanGenerated ? (
           <div className="min-h-full flex flex-col relative">
            {/* Abstract Background */}
            <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0 pointer-events-none">
              <div className="absolute top-[-20%] right-[-10%] w-[800px] h-[800px] bg-violet-500/10 rounded-full blur-[120px]"></div>
              <div className="absolute bottom-[-20%] left-[-10%] w-[600px] h-[600px] bg-emerald-500/5 rounded-full blur-[100px]"></div>
            </div>

            <div className="flex-1 flex items-center justify-center p-6 z-10">
              <div className="max-w-lg w-full">
                
                <div className="text-center mb-12">
                  <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 border border-slate-700 shadow-2xl mb-6">
                    <Rocket size={40} className="text-emerald-500" />
                  </div>
                  <h1 className="text-5xl font-black text-white tracking-tight mb-4">ZeroToHero</h1>
                  <p className="text-slate-400 text-lg">AI-Powered Revenue Architect.</p>
                  <p className="text-slate-500 text-sm mt-2">From $0 to $2,000 in 14 days using only free tools.</p>
                </div>

                <div className="bg-slate-900/60 backdrop-blur-xl p-8 rounded-3xl border border-slate-800 shadow-2xl">
                  {isLoading ? (
                    <div className="py-12 text-center space-y-6">
                      <div className="relative w-20 h-20 mx-auto">
                        <div className="absolute inset-0 border-4 border-slate-800 rounded-full"></div>
                        <div className="absolute inset-0 border-4 border-emerald-500 rounded-full border-t-transparent animate-spin"></div>
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-white animate-pulse">AI Architect Working</h3>
                        <p className="text-slate-400 mt-2 text-sm min-h-[20px]">
                          {["Analyzing Market...", "Structuring Revenue...", "Finalizing Roadmap..."][loadingStep]}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <form onSubmit={handleGeneratePlan} className="space-y-6">
                      <div>
                        <label className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 block">Select Your Strategy / Niche</label>
                        <div className="relative">
                          <input
                            type="text"
                            value={nicheInput}
                            onChange={(e) => setNicheInput(e.target.value)}
                            placeholder="e.g. SaaS Affiliate, Faceless YouTube, Digital Art..."
                            className="w-full bg-slate-950 border border-slate-700 rounded-xl py-4 px-5 text-white focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all placeholder-slate-600 text-lg"
                          />
                          <Zap className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-600" size={20} />
                        </div>
                      </div>
                      <button
                        type="submit"
                        disabled={!nicheInput}
                        className="w-full bg-white hover:bg-emerald-50 text-slate-900 font-bold py-4 rounded-xl transition-all shadow-xl shadow-white/5 flex items-center justify-center gap-2 disabled:opacity-50 disabled:shadow-none"
                      >
                        Generate Blueprint <ExternalLink size={18} />
                      </button>
                      <div className="text-center">
                         <button type="button" onClick={() => setIsSettingsOpen(true)} className="text-xs text-slate-500 hover:text-emerald-400 underline">Configure API Key</button>
                      </div>
                    </form>
                  )}
                </div>
                
                <p className="text-center text-slate-600 text-xs mt-8">
                  Powered by Gemini 2.5 Flash • Professional Edition
                </p>
              </div>
            </div>
          </div>
        ) : (
          /* Dashboard View */
          <div className="max-w-5xl mx-auto p-6 md:p-12">
            
            {/* Top Bar */}
            <div className="mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                  <h1 className="text-2xl md:text-3xl font-bold text-white tracking-tight">
                      {activeTab === 'plan' && 'Daily Operations'}
                      {activeTab === 'stats' && 'Financial Analytics'}
                      {activeTab === 'tools' && 'Tool Armory'}
                  </h1>
                  <p className="text-slate-400 text-sm mt-1">
                      {activeTab === 'plan' && `Day ${progress.currentDay} of 14 • Focus: ${currentDayPlan.focus}`}
                      {activeTab === 'stats' && 'Track your velocity towards $2,000.'}
                      {activeTab === 'tools' && 'Zero-cost assets to scale your business.'}
                  </p>
              </div>
              
              {activeTab === 'plan' && (
                  <div className="flex items-center gap-2 text-sm text-slate-400 bg-slate-900 px-4 py-2 rounded-full border border-slate-800">
                      <Target size={16} className="text-emerald-500" />
                      <span>Niche: <span className="text-white font-medium">{progress.niche}</span></span>
                  </div>
              )}
            </div>

            {/* Views */}
            {activeTab === 'plan' && (
              <DayView 
                plan={currentDayPlan}
                currentEarnings={progress.actualEarnings[progress.currentDay] || 0}
                onToggleTask={handleToggleTask}
                onUpdateEarnings={handleUpdateEarnings}
                onNextDay={() => setProgress(p => ({ ...p, currentDay: Math.min(14, p.currentDay + 1) }))}
                onPrevDay={() => setProgress(p => ({ ...p, currentDay: Math.max(1, p.currentDay - 1) }))}
                isFirstDay={progress.currentDay === 1}
                isLastDay={progress.currentDay === 14}
              />
            )}

            {activeTab === 'stats' && (
              <div className="space-y-6 animate-slide-up">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-10"><Target size={64} /></div>
                    <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-2">Campaign Goal</p>
                    <p className="text-3xl font-bold text-white">$2,000.00</p>
                    <p className="text-xs text-slate-400 mt-2">By Day 14</p>
                  </div>
                  <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-10"><BarChart3 size={64} /></div>
                    <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-2">Current Revenue</p>
                    <p className={`text-3xl font-bold ${totalEarnings > 0 ? 'text-emerald-400' : 'text-slate-300'}`}>${totalEarnings.toFixed(2)}</p>
                    <p className="text-xs text-emerald-500/80 mt-2">Total Aggregated</p>
                  </div>
                  <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-10"><Rocket size={64} /></div>
                    <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-2">Runway</p>
                    <p className="text-3xl font-bold text-violet-400">{14 - progress.currentDay} Days</p>
                    <p className="text-xs text-slate-400 mt-2">Remaining to hit target</p>
                  </div>
                </div>
                
                <ProgressChart plan={plan} actualEarnings={progress.actualEarnings} />
                
                <div className="bg-gradient-to-r from-slate-900 to-slate-900 border border-slate-800 p-8 rounded-2xl text-center">
                  <h3 className="text-white font-bold mb-2">Keep Pushing</h3>
                  <p className="text-slate-400 max-w-xl mx-auto text-sm">"Revenue is the only metric that matters. Everything else is just vanity. Stay focused on the daily tasks that generate cash."</p>
                </div>
              </div>
            )}

            {activeTab === 'tools' && (
              <div className="animate-slide-up space-y-8 pb-12">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {FREE_TOOLS.map((tool) => (
                    <div 
                      key={tool.name}
                      className="group bg-slate-900 rounded-2xl border border-slate-800 hover:border-emerald-500/30 hover:bg-slate-800/80 transition-all relative overflow-hidden flex flex-col"
                    >
                      <div className="p-6 flex-1">
                        <div className="flex justify-between items-start mb-4">
                          <div className={`p-3 rounded-xl inline-flex ${
                            tool.category === 'AI' ? 'bg-violet-500/10 text-violet-400' : 
                            tool.category === 'Marketplace' ? 'bg-emerald-500/10 text-emerald-400' : 
                            'bg-blue-500/10 text-blue-400'
                          }`}>
                            <Zap size={24} />
                          </div>
                          {tool.badge && (
                            <span className="inline-flex items-center px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-[10px] font-bold uppercase text-emerald-400 tracking-wider">
                              {tool.badge}
                            </span>
                          )}
                        </div>
                        
                        <h3 className="font-bold text-xl text-white mb-2 group-hover:text-emerald-400 transition-colors">
                          {tool.name}
                        </h3>
                        <p className="text-sm text-slate-400 leading-relaxed">
                          {tool.description}
                        </p>
                      </div>
                      
                      <div className="p-6 pt-0 mt-auto">
                        <a 
                          href={getToolUrl(tool)}
                          target="_blank"
                          rel="noreferrer"
                          className="w-full block text-center bg-slate-950 hover:bg-emerald-600 hover:text-white border border-slate-700 hover:border-emerald-600 text-slate-300 font-bold py-3 rounded-xl transition-all shadow-lg"
                        >
                          {tool.cta || 'Open Tool'} <ExternalLink size={14} className="inline ml-1 mb-0.5" />
                        </a>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="text-center border-t border-slate-800/50 pt-8">
                  <p className="text-[10px] text-slate-600 uppercase tracking-widest">Transparency Disclaimer</p>
                  <p className="text-xs text-slate-500 mt-2 max-w-2xl mx-auto">
                    Some links above are affiliate links. This means if you click on the link and purchase the item, we may receive an affiliate commission at no extra cost to you. This helps support the development of ZeroToHero.
                  </p>
                </div>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}

export default App;
