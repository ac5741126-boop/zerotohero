import React, { useState } from 'react';
import { DayPlan, Task } from '../types';
import { CheckCircle2, Circle, DollarSign, MessageSquare, ExternalLink, ChevronRight, ChevronLeft, Sparkles, Bot } from 'lucide-react';
import { askMentor } from '../services/geminiService';

interface DayViewProps {
  plan: DayPlan;
  currentEarnings: number;
  onToggleTask: (day: number, taskId: string) => void;
  onUpdateEarnings: (amount: number) => void;
  onNextDay: () => void;
  onPrevDay: () => void;
  isFirstDay: boolean;
  isLastDay: boolean;
}

const DayView: React.FC<DayViewProps> = ({
  plan,
  currentEarnings,
  onToggleTask,
  onUpdateEarnings,
  onNextDay,
  onPrevDay,
  isFirstDay,
  isLastDay
}) => {
  const [mentorInput, setMentorInput] = useState('');
  const [mentorResponse, setMentorResponse] = useState('');
  const [isLoadingMentor, setIsLoadingMentor] = useState(false);
  const [earningsInput, setEarningsInput] = useState('');

  const completedCount = plan.tasks.filter(t => t.completed).length;
  const totalTasks = plan.tasks.length;
  const progress = Math.round((completedCount / totalTasks) * 100);

  const handleMentorAsk = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mentorInput.trim()) return;
    setIsLoadingMentor(true);
    const response = await askMentor(mentorInput, plan.focus, plan.day);
    setMentorResponse(response);
    setIsLoadingMentor(false);
    setMentorInput('');
  };

  const handleEarningsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(earningsInput);
    if (!isNaN(val)) {
      onUpdateEarnings(val);
      setEarningsInput('');
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pb-20 md:pb-0">
      
      {/* LEFT COLUMN: Plan Details */}
      <div className="lg:col-span-2 space-y-6">
        
        {/* Hero Card */}
        <div className="bg-slate-900 rounded-2xl p-8 border border-slate-800 relative overflow-hidden group shadow-2xl">
          <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-emerald-500/10 to-transparent rounded-full blur-3xl -mr-24 -mt-24 pointer-events-none"></div>
          <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500 via-violet-500 to-emerald-500 opacity-30"></div>
          
          <div className="relative z-10">
            <div className="flex justify-between items-start mb-6">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-950 border border-slate-700 text-xs font-bold text-slate-400 uppercase tracking-wider">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> Day {plan.day}
                </span>
                <div className="text-right">
                    <p className="text-xs text-slate-500 font-medium uppercase tracking-wide mb-1">Revenue Target</p>
                    <p className="text-2xl font-mono font-bold text-emerald-400">${plan.revenueTarget}</p>
                </div>
            </div>

            <h2 className="text-3xl md:text-4xl font-black text-white mb-2 tracking-tight">{plan.focus}</h2>
            <p className="text-slate-400 text-lg leading-relaxed max-w-2xl border-l-2 border-emerald-500/30 pl-4">
              {plan.description}
            </p>
          </div>
        </div>

        {/* Tasks Section */}
        <div className="space-y-4">
            <div className="flex justify-between items-end px-1">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                    Execution List 
                    <span className="text-xs font-normal text-slate-500 bg-slate-900 px-2 py-0.5 rounded-md border border-slate-800">
                        {completedCount}/{totalTasks} Completed
                    </span>
                </h3>
            </div>

            <div className="space-y-3">
                {plan.tasks.map((task) => (
                <div 
                    key={task.id}
                    onClick={() => onToggleTask(plan.day, task.id)}
                    className={`group p-5 rounded-xl border transition-all duration-300 cursor-pointer select-none flex items-start gap-4 relative overflow-hidden
                    ${task.completed 
                        ? 'bg-slate-900/40 border-emerald-900/30' 
                        : 'bg-slate-900 border-slate-800 hover:border-slate-600 hover:shadow-lg hover:translate-y-[-1px]'
                    }`}
                >
                    {task.completed && (
                         <div className="absolute inset-0 bg-emerald-500/5 pointer-events-none"></div>
                    )}
                    
                    <div className={`mt-0.5 flex-shrink-0 transition-transform duration-300 ${task.completed ? 'text-emerald-500 scale-110' : 'text-slate-600 group-hover:text-emerald-500/50'}`}>
                    {task.completed ? <CheckCircle2 size={22} className="fill-emerald-500/10" /> : <Circle size={22} strokeWidth={2} />}
                    </div>
                    
                    <div className="flex-1 relative z-10">
                    <p className={`text-base font-medium transition-all ${task.completed ? 'text-slate-500 line-through decoration-slate-700' : 'text-slate-200'}`}>
                        {task.text}
                    </p>
                    {task.toolSuggestion && (
                        <div className="flex items-center gap-2 mt-3">
                            <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-violet-300 bg-violet-500/10 px-2 py-1 rounded border border-violet-500/20">
                                <ExternalLink size={10} /> {task.toolSuggestion}
                            </span>
                        </div>
                    )}
                    </div>
                </div>
                ))}
            </div>
        </div>

        {/* Navigation */}
        <div className="flex justify-between items-center pt-4 border-t border-slate-800/50">
            <button 
            onClick={onPrevDay}
            disabled={isFirstDay}
            className="flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-colors px-4 py-2"
            >
            <ChevronLeft size={16} /> Previous
            </button>
            <button 
            onClick={onNextDay}
            disabled={isLastDay}
            className="flex items-center gap-2 text-sm font-bold text-slate-900 bg-white hover:bg-emerald-50 px-6 py-2.5 rounded-lg transition-all shadow-lg shadow-slate-900/50 disabled:opacity-50"
            >
            Next Day <ChevronRight size={16} />
            </button>
        </div>
      </div>

      {/* RIGHT COLUMN: Tools & Mentor */}
      <div className="space-y-6">
        
        {/* Money Logger Widget */}
        <div className="bg-slate-900 rounded-2xl p-5 border border-slate-800 shadow-lg">
          <div className="flex items-center gap-2 mb-4">
             <div className="p-2 bg-emerald-500/10 rounded-lg text-emerald-500">
                <DollarSign size={18} />
             </div>
             <div>
                <h4 className="text-sm font-bold text-white">Revenue Logger</h4>
                <p className="text-xs text-slate-500">Track actuals for Day {plan.day}</p>
             </div>
          </div>
          
          <form onSubmit={handleEarningsSubmit} className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-mono">$</span>
            <input 
                type="number" 
                value={earningsInput}
                onChange={(e) => setEarningsInput(e.target.value)}
                placeholder={currentEarnings > 0 ? currentEarnings.toString() : "0.00"}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl py-3 pl-8 pr-20 text-white focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all placeholder-slate-600 font-mono"
            />
            <button 
                type="submit" 
                className="absolute right-1.5 top-1.5 bottom-1.5 bg-slate-800 hover:bg-emerald-600 hover:text-white text-slate-400 px-3 rounded-lg text-xs font-bold transition-colors"
            >
              SAVE
            </button>
          </form>
        </div>

        {/* AI Strategy Consultant */}
        <div className="bg-slate-900 rounded-2xl p-5 border border-slate-800 shadow-lg flex flex-col h-auto min-h-[300px]">
          <div className="flex items-center gap-2 mb-4 pb-4 border-b border-slate-800/50">
            <div className="p-2 bg-violet-500/10 rounded-lg text-violet-400">
                <Bot size={18} />
             </div>
            <div>
                <h4 className="text-sm font-bold text-white">AI Strategy Consultant</h4>
                <p className="text-xs text-slate-500">Context-aware assistance</p>
            </div>
          </div>

          <div className="flex-1 space-y-4 mb-4">
            {mentorResponse ? (
                <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4 animate-fade-in">
                    <div className="flex items-start gap-3">
                        <Sparkles size={16} className="text-violet-400 mt-0.5 flex-shrink-0" />
                        <p className="text-sm text-slate-300 leading-relaxed">{mentorResponse}</p>
                    </div>
                    <button 
                        onClick={() => setMentorResponse('')}
                        className="mt-3 text-xs text-slate-500 hover:text-white transition-colors"
                    >
                        Clear chat
                    </button>
                </div>
            ) : (
                <div className="text-center py-8 text-slate-600">
                    <MessageSquare size={32} className="mx-auto mb-2 opacity-20" />
                    <p className="text-xs">Ask for specific advice on today's tasks or how to pivot.</p>
                </div>
            )}
          </div>
          
          <form onSubmit={handleMentorAsk} className="mt-auto">
            <div className="relative">
                <input 
                    type="text" 
                    value={mentorInput}
                    onChange={(e) => setMentorInput(e.target.value)}
                    placeholder="e.g., How do I find clients?"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-3 pl-4 pr-12 text-sm text-white focus:outline-none focus:border-violet-500 transition-all"
                />
                <button 
                    disabled={isLoadingMentor || !mentorInput}
                    type="submit" 
                    className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 bg-violet-600 hover:bg-violet-500 disabled:opacity-50 disabled:hover:bg-violet-600 text-white rounded-lg transition-colors"
                >
                    {isLoadingMentor ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <ChevronRight size={16} />}
                </button>
            </div>
          </form>
        </div>

      </div>
    </div>
  );
};

export default DayView;